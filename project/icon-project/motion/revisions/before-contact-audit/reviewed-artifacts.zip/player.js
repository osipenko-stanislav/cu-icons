// Track tuple: part index, property, magnitude, pivot x/y, start/end fractions.
function mountMotion(root, parts, scene, preset) {
  if (scene.trigger==='static') return ()=>{};
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let frame = 0, started = 0, activePreset, original;
  const animatedAttributes = scene.tracks.flatMap(([index, kind]) => {
    const names = (kind==='draw'||kind==='erase-redraw') ? ['stroke-dasharray','stroke-dashoffset'] : ['transform'];
    return names.map(name => [parts[index],name]);
  });
  function stop() {
    cancelAnimationFrame(frame);
    frame = 0;
    root.querySelector('[id$="motion-idle"]')?.removeAttribute('visibility');
    root.querySelector('[id$="motion-active"]')?.setAttribute('visibility','hidden');
    if (!original) return;
    for (const [part,name,value] of original) {
      if (value===null) part.removeAttribute(name);
      else part.setAttribute(name,value);
    }
    original = null;
  }
  function strokeMetrics(part) {
    const style=getComputedStyle(part), width=parseFloat(style.strokeWidth)||1;
    let length=part.getTotalLength();
    if(style.vectorEffect==='non-scaling-stroke') {
      const matrix=part.getCTM();
      if(matrix) length*=Math.hypot(matrix.a,matrix.b);
    }
    return {length,padding:Math.max(1,width)+.1};
  }
  function paint(time) {
    const p = activePreset;
    const t = Math.min(1,(time-started)/(p.duration*scene.duration));
    for (const [index,kind,amount,x,y,from,to] of scene.tracks) {
      const part = parts[index];
      const local = Math.max(0,Math.min(1,(t-from)/(to-from)));
      if (kind==='erase-redraw') {
        if (local===0 || local===1) {
          for (const [node,name,value] of original) if(node===part) {
            if(value===null) part.removeAttribute(name); else part.setAttribute(name,value);
          }
        } else {
          // One dash and one gap travel along the full path: full -> empty -> full.
          // Padding clears round caps at the middle of the gap.
          const metrics=strokeMetrics(part);
          const span = metrics.length+metrics.padding;
          const progress = local*local*(3-2*local);
          part.setAttribute('stroke-dasharray',span+' '+span);
          part.setAttribute('stroke-dashoffset',-2*span*progress);
        }
        continue;
      }
      if (kind==='draw') {
        const {length,padding}=strokeMetrics(part);
        part.setAttribute('stroke-dasharray',length+' '+(length+padding*2));
        part.setAttribute('stroke-dashoffset', (length+padding)*(1-local*local*(3-2*local)));
        continue;
      }
      if (kind==='blink') {
        const factor = 1 - amount*Math.sin(Math.PI*local)**2;
        part.setAttribute('transform',`translate(0 ${y*(1-factor)}) scale(1 ${factor})`);
        continue;
      }
      const wave = p.curve==='spring'
        ? Math.sin(local*15)*Math.exp(-4*local)*Math.sin(Math.PI*local)*3
        : Math.sin(Math.PI*local)**2;
      if (kind==='scale'||kind==='scale-x'||kind==='scale-y') {
        const factor=1+Math.max(0,wave)*amount*p.amplitude;
        const sx=kind==='scale-y'?1:factor,sy=kind==='scale-x'?1:factor;
        part.setAttribute('transform',`translate(${x} ${y}) scale(${sx} ${sy}) translate(${-x} ${-y})`);
        continue;
      }
      const safeWave = (scene.id.startsWith('graduation-hat-')||scene.id.startsWith('rocket-')||scene.id==='moon-star-lined'||/^(arrow|arrows|chevron|corner)-/.test(scene.id)) ? Math.max(0,wave) : wave;
      const value = safeWave*amount*p.amplitude;
      part.setAttribute('transform',kind==='rotate' ? `rotate(${value} ${x} ${y})`
        : kind==='x' ? `translate(${value} 0)` : `translate(0 ${value})`);
    }
    if (t<1) frame=requestAnimationFrame(paint);
    else stop();
  }
  function play() {
    if (frame || reduced.matches) return;
    root.querySelector('[id$="motion-idle"]')?.setAttribute('visibility','hidden');
    root.querySelector('[id$="motion-active"]')?.removeAttribute('visibility');
    activePreset=preset();
    original=animatedAttributes.map(([part,name])=>[part,name,part.getAttribute(name)]);
    started=performance.now();
    paint(started);
  }
  root.addEventListener('click',()=>{if(['click-replay','hover-click'].includes(scene.trigger))play()});
  root.addEventListener('pointerenter',()=>{if(['hover','hover-click'].includes(scene.trigger))play()});
  play.stop=stop;
  reduced.addEventListener('change',stop);
  return play;
}