# CU icon restyle · 1.0

Task: redraw all 233 work metaphors using the supplied ref visual language; #000000 only. Preserve every filename and variant ID. Originals are immutable and hashed in manifest. Reference paths are not imported as substitute artwork.

## Authority and measurements
All 86 references use 24×24 viewBox. The dominant actual active stroke is 1 px, including inherited widths. The work set has 1.5 px strokes and mostly symmetric rounded containers. ref/success has a secondary .909091 stroke; do not average this outlier. Reference paint is white; user explicitly overrides it to #000000. No grayscale, opacity hierarchy, background fill, raster image, text artwork, masks or expanded strokes in outputs.

## Optical construction
Use 24×24 SVG with explicit width/height 24. Typical body bounds 3–21; wide forms may reach 1.5–22.5, circles 2–22, icons with bases 2–22. Align long orthogonal segments to integer/half units. Preserve open space, prefer a small number of geometric contours. Thin outline at 24 px is authoritative; 16 px is a legibility check, not a reason to increase the reference stroke. Use actual circles and tangent arcs; asymmetrical frames use radius 2–3 at selected diagonal corners and square opposite corners, not four softened corners.

## Anchors and families
- ref/file: square top-left and bottom-right, rounded lower-left, simple angular fold. ref/doc: rounded upper-left/lower-right, square other corners; rectangular clip with a single rounded corner. Keep file with no fold, folded file, internal marker, external marker and text-bearing variants distinct.
- ref/desktop and ref/calendar: opposing-corner frames; desktop has a shallow detached foot. Apply the appropriate opposing-corner pattern to new devices, battery, keyboard and folder body.
- ref/shield: horizontal top and straight sides, curved shoulders into angled lower point. Both empty and checked variants share the shield base.
- ref/cap-academic: flat rhombus, shallow rounded lower cap. Tassel follows source semantics; the selected work variant has none.
- ref/glasses: round lenses, airy bridge, visible temple arms; redraw those details rather than maintaining the work shortcut of two rings only.
- ref/trophy: plain cup, detached short vertical handles, slender stem, baseline. Suppress the thick ornamental pedestal.
- ref/book: wide pages, peaked central hinge, square top outer corners, round bottom outer corners. Its exported SVG uses a mask/expanded stroke; interpret the visible 1 px contour using live strokes in our output. Do not duplicate export mechanics.
- ref/coworking: bulb shoulder narrows into a flat neck; two separated cap lines; short radial rays. Preserve bulb-with-rays semantics of work/lightbulb-02.
- ref/award and ref/reward: concave points and ribbon geometry; rosette variants must retain their ribbons and lack/add central symbols according to their source.
- ref/play-circle and ref/play-square-lined: deliberate all-rounded media frame exception. Keep circle/square distinction, optically right-centered outlined triangle, gentle triangle tips.
- ref/wifi and ref/calendar: sparse filled dots are allowed only on these corresponding controls; structural outlines remain live strokes.
- ref/search, ref/check: simple unornamented modifiers, approximately 1.5–2 px visible clearance from surrounding strokes. Modifier anchors remain internal/external as in work.

## Anti-examples
Do not perform stroke-only batch conversion. Do not retain pill-rounded file/folder/monitor/shield outlines from work. Do not add unnecessary details, filled silhouettes, new symbols, extra tassels or merge source variants. Keep the broken-concentric fingerprint metaphor, separate from actual fingerprint-ridge variants.

## Review and limitations
Visual review is sequential by one agent; no independent critic was used. Local renderer: Chrome canvas, original SVG preserved. Ink bounds are estimated at 384 px (1/16 logical px), not analytic librsvg extents. Inspect 16/24/48 px and enlarged source/result/anchor comparisons. Reference technical clusters differ in caps/joins, filled control dots and export constructs; these are deliberate local exceptions, not alternate averaged styles. Pilot contains 24 of 233 icons; 209 remain planned pending explicit user approval. Technical pass does not imply user approval.
